@echo off
title VEDANT. Portfolio Local Server
echo ========================================================
echo   Launching VEDANT. Portfolio Local Server...
echo ========================================================
powershell -ExecutionPolicy Bypass -NoProfile -File "%~dp0serve.ps1"
if %ERRORLEVEL% NEQ 0 (
  echo.
  echo Server exited with code %ERRORLEVEL%.
  pause
)
