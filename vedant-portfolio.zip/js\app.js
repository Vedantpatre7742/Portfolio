/**
 * ====================================================================
 * VEDANT. — MAIN APPLICATION ENGINE
 * ====================================================================
 * Coordinates UI rendering, project filtering, modal previews,
 * clipboard interactions, and mobile navigation.
 * ====================================================================
 */

document.addEventListener("DOMContentLoaded", () => {
  // 1. Render data-driven sections from PORTFOLIO_DATA (config.js)
  renderHeroStats();
  renderSkillsSection();
  renderLearningJourney();
  renderProjectsGrid();
  renderEducationSection();
  renderSocialLinks();
  bindConfiguredData();

  // 2. Initialize interactive controllers
  initProjectFiltering();
  initCopyEmail();
  initContactForm();
  initMobileNav();
  initBackToTop();
  initProjectModal();

  // 3. Initialize Lucide Icons
  refreshIcons();

  // 4. Dynamic current year in footer
  const yearEl = document.getElementById("currentYear");
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }
});

/**
 * Re-runs Lucide icon generator whenever dynamic DOM updates happen
 */
function refreshIcons() {
  if (typeof lucide !== "undefined" && lucide.createIcons) {
    lucide.createIcons();
  }
}

/**
 * Syncs general text elements from PORTFOLIO_DATA
 */
function bindConfiguredData() {
  if (typeof PORTFOLIO_DATA === "undefined") return;

  const data = PORTFOLIO_DATA;

  // Introduction quote
  const quoteEl = document.getElementById("aboutQuoteText");
  if (quoteEl && data.personal.introduction) {
    quoteEl.textContent = `"${data.personal.introduction}"`;
  }

  // Secondary about text
  const aboutSecEl = document.getElementById("aboutSecondaryText");
  if (aboutSecEl && data.personal.aboutSecondary) {
    aboutSecEl.textContent = data.personal.aboutSecondary;
  }

  // Email placeholders in copy pills & links
  const emailTextEl = document.getElementById("emailCopyText");
  if (emailTextEl && data.contact.email) {
    emailTextEl.textContent = data.contact.email;
  }

  const directMailLink = document.getElementById("directMailLink");
  if (directMailLink && data.contact.email) {
    directMailLink.href = `mailto:${data.contact.email}`;
  }
}

/**
 * Renders Hero section quick statistic bento cards
 */
function renderHeroStats() {
  const container = document.getElementById("heroBentoGrid");
  if (!container || !PORTFOLIO_DATA?.personal?.stats) return;

  container.innerHTML = PORTFOLIO_DATA.personal.stats.map(stat => `
    <div class="hero-bento-card">
      <div class="hero-bento-icon">
        <i data-lucide="${stat.icon}"></i>
      </div>
      <div>
        <div class="hero-bento-value">${stat.value}</div>
        <div class="hero-bento-label">${stat.label}</div>
      </div>
    </div>
  `).join("");
}

/**
 * Renders Confirmed Core Skills (C, Python, WordPress)
 */
function renderSkillsSection() {
  const container = document.getElementById("skillsGridContainer");
  if (!container || !PORTFOLIO_DATA?.skills) return;

  container.innerHTML = PORTFOLIO_DATA.skills.map((skill, index) => `
    <div class="bento-card skill-card reveal-on-scroll reveal-delay-${index + 1}">
      <div>
        <div class="skill-card-top">
          <div class="skill-icon-wrap">
            <i data-lucide="${skill.icon}"></i>
          </div>
          <span class="badge badge-red">${skill.level}</span>
        </div>
        <div class="skill-category-tag">${skill.category}</div>
        <h3 class="skill-title">${skill.name}</h3>
        <p class="skill-desc">${skill.description}</p>
        
        <ul class="skill-points-list">
          ${skill.highlights.map(pt => `
            <li>
              <i data-lucide="check-circle-2"></i>
              <span>${pt}</span>
            </li>
          `).join("")}
        </ul>
      </div>

      <div class="terminal-card skill-snippet-preview">
        <div class="terminal-header">
          <div class="terminal-dots">
            <div class="terminal-dot red"></div>
            <div class="terminal-dot"></div>
            <div class="terminal-dot"></div>
          </div>
          <span class="terminal-title">${skill.id}.preview</span>
        </div>
        <pre class="terminal-body"><code>${escapeHtml(skill.sampleSnippet)}</code></pre>
      </div>
    </div>
  `).join("");
}

/**
 * Renders Currently Learning Journey Section
 */
function renderLearningJourney() {
  const container = document.getElementById("journeyGridContainer");
  if (!container || !PORTFOLIO_DATA?.learningJourney) return;

  container.innerHTML = PORTFOLIO_DATA.learningJourney.map((item, index) => `
    <div class="bento-card journey-card reveal-on-scroll reveal-delay-${(index % 2) + 1}">
      <div class="journey-header">
        <div class="hero-bento-icon">
          <i data-lucide="${item.icon}"></i>
        </div>
        <span class="badge badge-neutral">${item.status}</span>
      </div>
      <div class="journey-phase">${item.phase}</div>
      <h3 class="journey-title">${item.title}</h3>
      <p class="journey-desc">${item.description}</p>
    </div>
  `).join("");
}

/**
 * Maps project screenshot type to asset path
 */
function getProjectMockupPath(type) {
  const mapping = {
    "c-terminal": "assets/images/c-memory.svg",
    "python-cli": "assets/images/python-automation.svg",
    "wp-portal": "assets/images/wp-portal.svg",
    "python-algo": "assets/images/python-algo.svg",
    "c-library": "assets/images/c-library.svg",
    "future-concept": "assets/images/future-concept.svg"
  };
  return mapping[type] || "assets/images/c-memory.svg";
}

/**
 * Renders Reusable Projects Grid
 */
function renderProjectsGrid() {
  const container = document.getElementById("projectsGridContainer");
  if (!container || !PORTFOLIO_DATA?.projects) return;

  container.innerHTML = PORTFOLIO_DATA.projects.map((proj, index) => {
    const mockupSrc = getProjectMockupPath(proj.screenshotType);

    return `
      <div class="project-item reveal-on-scroll reveal-delay-${(index % 3) + 1}" data-category="${proj.category}" id="proj-${proj.id}">
        <div class="project-card">
          <div class="project-card-media">
            <img src="${mockupSrc}" alt="${proj.title} Mockup Preview" loading="lazy">
            <div class="project-card-overlay-badge">
              <span class="badge badge-placeholder">Editable Placeholder</span>
            </div>
            <div class="project-card-category-pill">
              <span class="badge badge-red">${proj.badge}</span>
            </div>
          </div>

          <div class="project-card-body">
            <h3 class="project-card-title">${proj.title}</h3>
            <p class="project-card-desc">${proj.description}</p>

            <ul class="project-highlights-list">
              ${proj.keyHighlights.slice(0, 2).map(highlight => `
                <li>
                  <i data-lucide="chevron-right"></i>
                  <span>${highlight}</span>
                </li>
              `).join("")}
            </ul>

            <div class="project-card-tech">
              ${proj.technologies.map(tech => `<span class="badge badge-tech">#${tech}</span>`).join("")}
            </div>

            <div class="project-card-actions">
              <a href="${proj.githubUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-secondary btn-sm" title="View Source on GitHub">
                <i data-lucide="github"></i> Source
              </a>
              <button type="button" class="btn btn-primary btn-sm open-preview-btn" data-project-id="${proj.id}">
                <i data-lucide="external-link"></i> Live Details
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  }).join("");
}

/**
 * Renders Editable Education Section
 */
function renderEducationSection() {
  const container = document.getElementById("educationContainer");
  if (!container || !PORTFOLIO_DATA?.education?.items) return;

  container.innerHTML = PORTFOLIO_DATA.education.items.map((edu, index) => `
    <div class="bento-card education-card reveal-on-scroll reveal-delay-${index + 1}">
      <div class="education-top">
        <div>
          <h3 class="education-degree">${edu.degree}</h3>
          <div class="education-institution">${edu.institution}</div>
        </div>
        <div class="education-period-badge">${edu.period}</div>
      </div>
      <p class="education-desc">${edu.description}</p>
      
      <div class="education-coursework-title">Relevant Core Coursework:</div>
      <div class="education-tags">
        ${edu.coursework.map(course => `<span class="badge badge-tech">${course}</span>`).join("")}
      </div>
    </div>
  `).join("");
}

/**
 * Renders Social Media & Contact Cards
 */
function renderSocialLinks() {
  const container = document.getElementById("socialLinksContainer");
  if (!container || !PORTFOLIO_DATA?.contact?.socials) return;

  container.innerHTML = PORTFOLIO_DATA.contact.socials.map(item => `
    <a href="${item.url}" target="_blank" rel="noopener noreferrer" class="social-link-card">
      <i data-lucide="${item.icon}"></i>
      <div class="social-link-info">
        <span class="social-link-name">${item.platform}</span>
        <span class="social-link-handle">${item.username}</span>
      </div>
    </a>
  `).join("");
}

/**
 * Project Category Filter System
 */
function initProjectFiltering() {
  const filterButtons = document.querySelectorAll(".filter-btn");
  const projectItems = document.querySelectorAll(".project-item");

  filterButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      filterButtons.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");

      const filterVal = btn.getAttribute("data-filter");

      projectItems.forEach(item => {
        const itemCategory = item.getAttribute("data-category");
        if (filterVal === "all" || itemCategory === filterVal) {
          item.classList.remove("hidden");
        } else {
          item.classList.add("hidden");
        }
      });
    });
  });
}

/**
 * One-Click Copy Email Pill with Toast Alert
 */
function initCopyEmail() {
  const copyPill = document.getElementById("emailCopyPill");
  if (!copyPill) return;

  copyPill.addEventListener("click", () => {
    const email = PORTFOLIO_DATA?.contact?.email || "vedant.developer@example.com";

    navigator.clipboard.writeText(email)
      .then(() => {
        showToast(`Email copied: ${email}`);
      })
      .catch(() => {
        // Fallback for older browsers
        const textarea = document.createElement("textarea");
        textarea.value = email;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand("copy");
        document.body.removeChild(textarea);
        showToast(`Email copied: ${email}`);
      });
  });
}

/**
 * Toast Notification Utility
 */
function showToast(message) {
  let toastContainer = document.querySelector(".toast-container");
  if (!toastContainer) {
    toastContainer = document.createElement("div");
    toastContainer.className = "toast-container";
    document.body.appendChild(toastContainer);
  }

  const toast = document.createElement("div");
  toast.className = "toast";
  toast.innerHTML = `<i data-lucide="check"></i> <span>${escapeHtml(message)}</span>`;
  toastContainer.appendChild(toast);
  refreshIcons();

  // Trigger animation
  setTimeout(() => toast.classList.add("show"), 50);

  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.remove(), 400);
  }, 3200);
}

/**
 * Interactive Contact Form
 */
function initContactForm() {
  const form = document.getElementById("contactForm");
  if (!form) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const name = document.getElementById("senderName")?.value.trim();
    const email = document.getElementById("senderEmail")?.value.trim();
    const subject = document.getElementById("msgSubject")?.value.trim();
    const message = document.getElementById("msgBody")?.value.trim();

    if (!name || !email || !message) {
      showToast("Please fill in your name, email, and message.");
      return;
    }

    // Direct mailto generation so message opens directly in user's mail client
    const targetEmail = PORTFOLIO_DATA?.contact?.email || "vedant.developer@example.com";
    const mailtoUrl = `mailto:${targetEmail}?subject=${encodeURIComponent(subject || `Portfolio Inquiry from ${name}`)}&body=${encodeURIComponent(`Hi Vedant,\n\nName: ${name}\nEmail: ${email}\n\nMessage:\n${message}`)}`;

    window.location.href = mailtoUrl;

    showToast("Launching your email client to send message...");
    form.reset();
  });
}

/**
 * Mobile Navigation Drawer
 */
function initMobileNav() {
  const toggleBtn = document.getElementById("mobileToggle");
  const drawer = document.getElementById("mobileNavDrawer");
  const backdrop = document.getElementById("mobileDrawerBackdrop");
  const mobileLinks = document.querySelectorAll(".mobile-nav-link");

  if (!toggleBtn || !drawer || !backdrop) return;

  const openDrawer = () => {
    drawer.classList.add("open");
    backdrop.classList.add("active");
    document.body.style.overflow = "hidden";
  };

  const closeDrawer = () => {
    drawer.classList.remove("open");
    backdrop.classList.remove("active");
    document.body.style.overflow = "";
  };

  toggleBtn.addEventListener("click", () => {
    if (drawer.classList.contains("open")) {
      closeDrawer();
    } else {
      openDrawer();
    }
  });

  backdrop.addEventListener("click", closeDrawer);

  mobileLinks.forEach(link => {
    link.addEventListener("click", closeDrawer);
  });

  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && drawer.classList.contains("open")) {
      closeDrawer();
    }
  });
}

/**
 * Project Details Modal Dialog
 */
function initProjectModal() {
  const modal = document.getElementById("projectModal");
  const closeBtn = document.getElementById("modalCloseBtn");
  if (!modal || !closeBtn) return;

  // Delegate clicks on preview buttons
  document.addEventListener("click", (e) => {
    const btn = e.target.closest(".open-preview-btn");
    if (!btn) return;

    const projectId = btn.getAttribute("data-project-id");
    const project = PORTFOLIO_DATA?.projects?.find(p => p.id === projectId);
    if (!project) return;

    populateModal(project);
    modal.classList.add("active");
    document.body.style.overflow = "hidden";
  });

  const closeModal = () => {
    modal.classList.remove("active");
    document.body.style.overflow = "";
  };

  closeBtn.addEventListener("click", closeModal);

  modal.addEventListener("click", (e) => {
    if (e.target === modal) closeModal();
  });

  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && modal.classList.contains("active")) {
      closeModal();
    }
  });
}

/**
 * Populates Modal Content with Project Data
 */
function populateModal(proj) {
  const titleEl = document.getElementById("modalProjectTitle");
  const descEl = document.getElementById("modalProjectDesc");
  const techEl = document.getElementById("modalProjectTech");
  const highlightsEl = document.getElementById("modalProjectHighlights");
  const githubLink = document.getElementById("modalGithubLink");
  const liveNotice = document.getElementById("modalLiveNotice");

  if (titleEl) titleEl.textContent = proj.title;
  if (descEl) descEl.textContent = proj.description;

  if (techEl) {
    techEl.innerHTML = proj.technologies.map(t => `<span class="badge badge-tech">#${t}</span>`).join("");
  }

  if (highlightsEl) {
    highlightsEl.innerHTML = proj.keyHighlights.map(h => `
      <li style="display: flex; gap: 8px; margin-bottom: 8px; color: #E4E4E7; font-size: 0.92rem;">
        <i data-lucide="check" style="color: var(--accent-red); width: 16px; flex-shrink: 0; margin-top: 3px;"></i>
        <span>${h}</span>
      </li>
    `).join("");
  }

  if (githubLink) {
    githubLink.href = proj.githubUrl;
  }

  if (liveNotice) {
    liveNotice.textContent = proj.isPlaceholder 
      ? "Note: This is a customizable placeholder card ready for your live repository & deployment URL."
      : "Active deployment preview available.";
  }

  refreshIcons();
}

/**
 * Back to Top Smooth Scroll
 */
function initBackToTop() {
  const btn = document.getElementById("backToTopBtn");
  if (!btn) return;

  btn.addEventListener("click", () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  });
}

/**
 * Utility: HTML Escape for safe snippet injection
 */
function escapeHtml(text) {
  if (!text) return "";
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
