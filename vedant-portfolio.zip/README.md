# VEDANT. — Personal Developer Portfolio

A personal portfolio website engineered for **Vedant**, a software developer specializing in **C Programming**, **Python**, and **WordPress Website Development**.

Built with a black, white, and red design aesthetic inspired by high-end developer websites and tech portfolios.

---

## 🎨 Visual Identity & Architecture

- **Color Palette:**
  - Background: `#090909` (Deep Obsidian)
  - Bento Surface: `#151515`
  - Accent Color: `#E53935` (Electric Crimson)
  - Typography: `#FFFFFF` / Zinc `#A1A1AA`
- **Typography:**
  - Headings: `Syne` (Oversized, modern brutalist aesthetic)
  - Body: `Plus Jakarta Sans` (Clean, high legibility)
  - Code & Badges: `JetBrains Mono`
- **Key Features:**
  - Asymmetric Bento Grid layout
  - Cinematic Hero Section with ambient glow aura tracking
  - Reusable Project Card Architecture with category filtering
  - Strictly Confirmed Core Skills (C, Python, WordPress)
  - Dedicated "Currently Learning" Journey roadmap
  - Fully editable academic history in Education
  - One-click copy email pill with toast alert feedback
  - Interactive Project Preview Modal dialog
  - Fully responsive across Desktop, Laptop, Tablet, and Mobile
  - Zero framework dependencies (Pure HTML5, CSS3, Vanilla JS, Lucide Icons)

---

## 📁 Project Structure

```
vedant-portfolio/
│
├── index.html                   # Core semantic HTML5 document
│
├── css/
│   ├── variables.css            # Design tokens (colors, radii, glows, fonts)
│   ├── base.css                 # CSS reset, typography, ambient grid & aura
│   ├── components.css           # Bento cards, buttons, badges, modals, toast
│   ├── sections.css             # Navigation, Hero, About, Skills, Journey, Projects, Education, Contact
│   ├── animations.css           # Keyframes, scroll reveals, breathing glows
│   └── responsive.css           # Mobile, tablet, and widescreen breakpoints
│
├── js/
│   ├── config.js                # ⭐ SINGLE SOURCE OF TRUTH: Edit all your info here!
│   ├── animations.js            # Scroll reveals, ambient cursor glow, card tilt
│   └── app.js                   # Dynamic rendering, filters, modal, toast, mailto
│
├── assets/
│   └── images/                  # High-fidelity SVG project mockups & assets
│       ├── c-memory.svg
│       ├── python-automation.svg
│       ├── wp-portal.svg
│       ├── python-algo.svg
│       ├── c-library.svg
│       └── future-concept.svg
│
└── README.md                    # Documentation & deployment guide
```

---

## ✏️ How to Customize Your Portfolio

All your personal details, skills, project cards, education, and social links are centralized in a single configuration file:

👉 **`js/config.js`**

### 1. Update Personal & Contact Information
Open `js/config.js` and edit the `personal` and `contact` blocks:
```javascript
personal: {
  name: "Vedant",
  brand: "VEDANT.",
  title: "Software Developer",
  statusBadge: "Available for Projects & Opportunities",
  // ...
},
contact: {
  email: "your.real.email@domain.com",
  socials: [
    { platform: "GitHub", url: "https://github.com/your-username", username: "github.com/your-username", icon: "github" },
    { platform: "LinkedIn", url: "https://linkedin.com/in/your-username", username: "linkedin.com/in/your-username", icon: "linkedin" }
  ]
}
```

### 2. Add or Modify Projects
Inside `PORTFOLIO_DATA.projects` in `js/config.js`, update the placeholder entries with your actual GitHub links and live demos:
```javascript
{
  id: "my-custom-project",
  title: "Your Project Name",
  category: "c", // or "python", "wordpress", "future"
  categoryLabel: "C Systems",
  badge: "Featured",
  isPlaceholder: false, // Set to false when ready!
  description: "Description of your software or website...",
  technologies: ["C", "POSIX", "Data Structures"],
  screenshotType: "c-terminal",
  githubUrl: "https://github.com/your-username/repo-name",
  liveUrl: "https://your-demo-url.com",
  keyHighlights: [
    "Key engineering achievement 1",
    "Key engineering achievement 2"
  ]
}
```

### 3. Update Education
Inside `PORTFOLIO_DATA.education`, replace the placeholder university and coursework with your actual educational credentials.

---

## 🚀 Running Locally

You can run this website instantly using any local web server or even open `index.html` directly in your browser.

### Option 1: Python HTTP Server (Recommended)
Open your terminal in the `vedant-portfolio` folder and run:
```bash
python -m http.server 8000
```
Then visit: `http://localhost:8000`

### Option 2: Node.js `serve` / `npx`
```bash
npx serve .
```

### Option 3: VS Code Live Server
Right-click `index.html` and click **"Open with Live Server"**.

---

## 🌐 How to Deploy for Free

### Method A: Deploy with Vercel (Fastest & Recommended)

1. **Push your code to a GitHub repository:**
   ```bash
   git init
   git add .
   git commit -m "Initial commit of Vedant personal portfolio"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/vedant-portfolio.git
   git push -u origin main
   ```
2. Go to [vercel.com](https://vercel.com) and log in with GitHub.
3. Click **"Add New Project"** and select `vedant-portfolio`.
4. Click **"Deploy"**. Vercel will instantly publish your site with a custom `.vercel.app` domain and free SSL!

### Method B: Deploy with GitHub Pages

1. In your GitHub repository, click on the **Settings** tab.
2. In the left navigation, click **Pages**.
3. Under **Branch**, select `main` and root `/` folder, then click **Save**.
4. In about 60 seconds, your portfolio will be live at:
   `https://YOUR_USERNAME.github.io/vedant-portfolio/`
