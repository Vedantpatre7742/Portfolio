/**
 * ====================================================================
 * VEDANT. — ANIMATIONS & INTERACTIVE MOTION ENGINE
 * ====================================================================
 */

document.addEventListener("DOMContentLoaded", () => {
  initAmbientAura();
  initScrollReveal();
  initNavbarScroll();
  initSectionSpy();
  initCardTilt();
});

/**
 * Ambient Glow Follower:
 * Smoothly interpolates red ambient light aura toward mouse coordinates
 */
function initAmbientAura() {
  const aura = document.getElementById("ambientAura");
  if (!aura) return;

  // Disable mouse tracking on touch devices for optimal battery/performance
  if (window.matchMedia("(pointer: coarse)").matches) {
    aura.style.top = "20%";
    aura.style.left = "50%";
    return;
  }

  let mouseX = window.innerWidth / 2;
  let mouseY = window.innerHeight / 2;
  let auraX = mouseX;
  let auraY = mouseY;

  window.addEventListener("mousemove", (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;
  }, { passive: true });

  function renderAura() {
    // Smooth lerp interpolation
    auraX += (mouseX - auraX) * 0.08;
    auraY += (mouseY - auraY) * 0.08;

    aura.style.transform = `translate(${auraX}px, ${auraY}px) translate(-50%, -50%)`;
    requestAnimationFrame(renderAura);
  }

  requestAnimationFrame(renderAura);
}

/**
 * Scroll Reveal:
 * Uses IntersectionObserver to trigger smooth fade-and-lift animations
 */
function initScrollReveal() {
  const revealElements = document.querySelectorAll(".reveal-on-scroll");

  if (!("IntersectionObserver" in window)) {
    // Fallback if browser doesn't support IntersectionObserver
    revealElements.forEach(el => el.classList.add("is-revealed"));
    return;
  }

  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-revealed");
        obs.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.12,
    rootMargin: "0px 0px -40px 0px"
  });

  revealElements.forEach(el => observer.observe(el));
}

/**
 * Sticky Navbar Header Scroll State
 */
function initNavbarScroll() {
  const header = document.querySelector(".site-header");
  if (!header) return;

  const handleScroll = () => {
    if (window.scrollY > 40) {
      header.classList.add("scrolled");
    } else {
      header.classList.remove("scrolled");
    }
  };

  window.addEventListener("scroll", handleScroll, { passive: true });
  handleScroll();
}

/**
 * Active Navigation Spy:
 * Automatically marks current section link in navbar
 */
function initSectionSpy() {
  const sections = document.querySelectorAll("section[id]");
  const navLinks = document.querySelectorAll(".nav-link");
  const mobileNavLinks = document.querySelectorAll(".mobile-nav-link");

  if (!sections.length || !navLinks.length) return;

  const spyObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.getAttribute("id");

        navLinks.forEach(link => {
          if (link.getAttribute("href") === `#${id}`) {
            link.classList.add("active");
          } else {
            link.classList.remove("active");
          }
        });

        mobileNavLinks.forEach(link => {
          if (link.getAttribute("href") === `#${id}`) {
            link.classList.add("active");
          } else {
            link.classList.remove("active");
          }
        });
      }
    });
  }, {
    threshold: 0.35,
    rootMargin: "-80px 0px -40% 0px"
  });

  sections.forEach(section => spyObserver.observe(section));
}

/**
 * Subtle 3D Card Tilt Effect on Mouse Movement
 */
function initCardTilt() {
  if (window.matchMedia("(pointer: coarse)").matches) return;

  const cards = document.querySelectorAll(".bento-card, .project-card");

  cards.forEach(card => {
    card.addEventListener("mousemove", (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      const centerX = rect.width / 2;
      const centerY = rect.height / 2;

      const deltaX = (x - centerX) / centerX;
      const deltaY = (y - centerY) / centerY;

      // Subtle tilt: max 2.5 degrees
      const tiltX = -deltaY * 2.5;
      const tiltY = deltaX * 2.5;

      card.style.transform = `perspective(1000px) rotateX(${tiltX.toFixed(2)}deg) rotateY(${tiltY.toFixed(2)}deg) translateY(-4px)`;
    });

    card.addEventListener("mouseleave", () => {
      card.style.transform = "";
    });
  });
}
