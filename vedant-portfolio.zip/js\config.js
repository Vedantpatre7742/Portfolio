/**
 * ====================================================================
 * VEDANT. — PORTFOLIO CONFIGURATION FILE
 * ====================================================================
 * This is the central source of truth for all personal details,
 * skills, projects, and contact information on your website.
 * 
 * TO UPDATE YOUR PORTFOLIO:
 * Simply edit the values in this file! No need to hunt through HTML tags.
 * ====================================================================
 */

const PORTFOLIO_DATA = {
  // --- Personal Information ---
  personal: {
    name: "Vedant",
    brand: "VEDANT.",
    title: "Software Developer",
    subTitle: "All-round Developer Portfolio",
    statusBadge: "Available for Projects & Opportunities",
    isAvailable: true,
    location: "Available Globally / Remote",
    
    // Exact official quote as requested
    introduction: "Hello, I'm Vedant — a software developer passionate about technology, programming, and building useful digital experiences. I enjoy exploring new technologies, solving problems, and continuously improving my development skills.",
    
    aboutSecondary: "My development philosophy revolves around writing clean, readable code and understanding fundamentals from the ground up. Whether architecting low-level algorithms in C, writing automation scripts in Python, or delivering custom WordPress websites, I take pride in crafting thoughtful, reliable digital solutions.",
    
    // Quick statistics / highlights shown in the hero bento
    stats: [
      { label: "Core Focus", value: "C & Python", icon: "terminal" },
      { label: "Web Solutions", value: "WordPress", icon: "layout" },
      { label: "Engineering Mindset", value: "Problem Solver", icon: "cpu" },
      { label: "Growth Mode", value: "Continuous Learner", icon: "sparkles" }
    ]
  },

  // --- Confirmed Core Skills (Strictly validated) ---
  skills: [
    {
      id: "c-programming",
      name: "C Programming",
      category: "Systems & Core Languages",
      level: "Proficient",
      icon: "code-2",
      description: "Fundamental systems programming focusing on memory efficiency, pointers, custom data structures, and optimized algorithmic execution.",
      highlights: [
        "Memory Management & Pointers",
        "Data Structures (Linked Lists, Stacks, Trees)",
        "Modular Code & Header Architecture",
        "Algorithmic Problem Solving",
        "Performance & Complexity Optimization"
      ],
      sampleSnippet: `// Efficient dynamic array in C
int* create_buffer(size_t capacity) {
    int *buf = (int*)malloc(capacity * sizeof(int));
    if (!buf) {
        fprintf(stderr, "Allocation failed\\n");
        exit(EXIT_FAILURE);
    }
    return buf;
}`
    },
    {
      id: "python-programming",
      name: "Python Programming",
      category: "Scripting & Software Logic",
      level: "Proficient",
      icon: "file-code",
      description: "Developing clean, expressive Python applications for algorithmic computation, task automation, data handling, and backend logic.",
      highlights: [
        "Object-Oriented Programming (OOP)",
        "Automation Scripts & File I/O",
        "Algorithm Design & Optimization",
        "Data Parsing & Manipulation",
        "Clean, Pythonic Code Standards"
      ],
      sampleSnippet: `# Clean algorithmic data processing
def find_optimal_subsequence(data_stream: list[int]) -> dict:
    seen, max_window = {}, 0
    for idx, value in enumerate(data_stream):
        # Process continuous data flow efficiently
        seen[value] = idx
    return {"unique_elements": len(seen)}`
    },
    {
      id: "wordpress-dev",
      name: "WordPress Development",
      category: "CMS & Web Architecture",
      level: "Proficient",
      icon: "globe",
      description: "Designing, building, and maintaining responsive WordPress sites with custom layout customization, plugin integration, and performance tuning.",
      highlights: [
        "Custom Theme Tweaking & Child Themes",
        "Responsive & Cross-Device UI Design",
        "Plugin Setup, Audit & Maintenance",
        "Page Speed Optimization & Caching",
        "SEO-Friendly Structure & CMS Management"
      ],
      sampleSnippet: `/* Custom responsive theme typography & accents */
:root {
  --wp-theme-accent: #E53935;
  --wp-content-font: 'Plus Jakarta Sans', sans-serif;
}
.site-branding .site-title {
  font-family: 'Syne', sans-serif;
  letter-spacing: -0.04em;
}`
    }
  ],

  // --- Currently Learning Section (Clearly differentiated exploration) ---
  learningJourney: [
    {
      title: "Data Structures & Algorithms (Advanced)",
      status: "In Progress",
      phase: "Phase 1: Deepening Efficiency",
      icon: "binary",
      description: "Mastering trees, graphs, dynamic programming, and time/space complexity analysis to write high-scale algorithms."
    },
    {
      title: "Modern Frontend Frameworks",
      status: "Exploring",
      phase: "Phase 2: Component Architecture",
      icon: "layers",
      description: "Investigating reactive state management, modern single-page applications, and component lifecycles."
    },
    {
      title: "Backend Architecture & REST APIs",
      status: "Exploring",
      phase: "Phase 3: Service Design",
      icon: "server",
      description: "Studying server-side API design patterns, client-server data flow, database querying, and authentication mechanisms."
    },
    {
      title: "DevOps Fundamentals & Git Workflow",
      status: "Active Practice",
      phase: "Ongoing",
      icon: "git-branch",
      description: "Consistently practicing branching models, GitHub project management, and automated continuous deployment workflows."
    }
  ],

  // --- Reusable Project System (Clearly labelled placeholders ready to be customized) ---
  projects: [
    {
      id: "c-memory-visualizer",
      title: "Memory Allocation & Process Manager",
      category: "c",
      categoryLabel: "C Programming",
      badge: "C Systems",
      isPlaceholder: true,
      description: "A lightweight terminal-based memory inspector and block allocator simulation written in C. Simulates heap fragmentation, garbage collection strategies, and pointer safety checks.",
      technologies: ["C", "Pointers", "Memory Management", "Algorithms"],
      screenshotType: "c-terminal", // SVG styled mockup
      githubUrl: "https://github.com/vedant-placeholder/c-memory-manager",
      liveUrl: "#preview-modal",
      featured: true,
      keyHighlights: [
        "Dynamic block allocation simulation (malloc/free)",
        "Memory leak detector with audit report",
        "ANSI terminal visual map of memory blocks"
      ]
    },
    {
      id: "python-automation-suite",
      title: "Automated Data Scraper & Reporter",
      category: "python",
      categoryLabel: "Python Scripting",
      badge: "Python Utility",
      isPlaceholder: true,
      description: "An automated Python CLI pipeline that extracts, validates, and aggregates structured dataset reports with real-time status output and automated logging.",
      technologies: ["Python 3", "Automation", "Data Parsing", "CLI"],
      screenshotType: "python-cli",
      githubUrl: "https://github.com/vedant-placeholder/python-automation-suite",
      liveUrl: "#preview-modal",
      featured: true,
      keyHighlights: [
        "Configurable batch processing pipeline",
        "Error handling with automated retry fallback",
        "Clean terminal dashboard with progress indicators"
      ]
    },
    {
      id: "wordpress-agency-portal",
      title: "Custom Responsive Business CMS Portal",
      category: "wordpress",
      categoryLabel: "WordPress Development",
      badge: "WordPress Site",
      isPlaceholder: true,
      description: "A modern, high-speed corporate WordPress deployment engineered with customized templates, responsive mobile layouts, and strict SEO compliance.",
      technologies: ["WordPress", "Custom CSS", "Responsive Design", "SEO"],
      screenshotType: "wp-portal",
      githubUrl: "https://github.com/vedant-placeholder/wordpress-custom-portal",
      liveUrl: "https://example.com/vedant-wordpress-demo",
      featured: true,
      keyHighlights: [
        "Mobile-first responsive fluid grid",
        "Sub-1 second load time optimization",
        "Custom editorial workflows and blocks"
      ]
    },
    {
      id: "python-algorithm-lab",
      title: "Algorithmic Problem-Solving Benchmarks",
      category: "python",
      categoryLabel: "Python Algorithms",
      badge: "Python Lab",
      isPlaceholder: true,
      description: "A comprehensive repository of algorithmic solutions implemented in Python with unit tests, benchmark timers, and space-time Big-O documentation.",
      technologies: ["Python", "Algorithms", "Unit Testing", "Big-O Analysis"],
      screenshotType: "python-algo",
      githubUrl: "https://github.com/vedant-placeholder/algorithm-benchmarks",
      liveUrl: "#preview-modal",
      featured: false,
      keyHighlights: [
        "Comparative benchmark suite for search & sorting",
        "Automated unit test runs",
        "Structured documentation of trade-offs"
      ]
    },
    {
      id: "c-data-structures",
      title: "High-Performance Data Structures Library",
      category: "c",
      categoryLabel: "C Programming",
      badge: "C Library",
      isPlaceholder: true,
      description: "A standalone, zero-dependency C library implementing resilient generic data structures including hash maps, binary search trees, and circular buffers.",
      technologies: ["C", "Data Structures", "Pointers", "Unit Testing"],
      screenshotType: "c-library",
      githubUrl: "https://github.com/vedant-placeholder/c-data-structures",
      liveUrl: "#preview-modal",
      featured: false,
      keyHighlights: [
        "Type-agnostic generic void pointer implementation",
        "Strict Valgrind zero-leak validation",
        "Comprehensive header documentation"
      ]
    },
    {
      id: "future-software-project",
      title: "Developer Toolkit & Utility Platform",
      category: "future",
      categoryLabel: "Future Concept",
      badge: "In Planning",
      isPlaceholder: true,
      description: "An upcoming software suite designed to streamline local developer environments, code snippet management, and system telemetry.",
      technologies: ["Architecture", "System Tools", "Python", "Web APIs"],
      screenshotType: "future-concept",
      githubUrl: "https://github.com/vedant-placeholder/dev-toolkit-concept",
      liveUrl: "#preview-modal",
      featured: false,
      keyHighlights: [
        "Cross-platform modular design",
        "Lightweight resource footprint",
        "Active architectural design phase"
      ]
    }
  ],

  // --- Education (Academic Background — Fully Editable) ---
  education: {
    notice: "This section is easily customizable. Replace these placeholders with your actual university, college, or school records.",
    items: [
      {
        degree: "Bachelor of Technology / Computer Science & Engineering",
        institution: "Your University / College Name Here",
        period: "2022 — Present (Editable)",
        status: "Currently Enrolled",
        description: "Engaging in comprehensive computer science curriculum, core programming coursework, software engineering principles, and hands-on laboratory projects.",
        coursework: [
          "Computer Programming in C",
          "Object-Oriented Programming & Python",
          "Data Structures & Algorithms",
          "Operating Systems & Architecture",
          "Web Technologies & Database Systems"
        ]
      },
      {
        degree: "Higher Secondary School / Pre-University Education",
        institution: "Your Senior High School / Junior College Here",
        period: "Completed (Editable)",
        status: "Graduated",
        description: "Focused on Science & Mathematics curriculum with emphasis on analytical problem solving and introductory computer science fundamentals.",
        coursework: [
          "Mathematics & Analytical Reasoning",
          "Physics & Logical Systems",
          "Foundational Information Technology"
        ]
      }
    ]
  },

  // --- Contact & Social Links (Clearly marked placeholders) ---
  contact: {
    email: "vedant.developer@example.com", // Replace with real email
    emailPlaceholderNote: "Click to copy or compose message directly",
    location: "India / Available for Remote Work",
    socials: [
      {
        platform: "GitHub",
        url: "https://github.com/vedant-placeholder",
        username: "github.com/vedant-placeholder",
        icon: "github"
      },
      {
        platform: "LinkedIn",
        url: "https://linkedin.com/in/vedant-placeholder",
        username: "linkedin.com/in/vedant-placeholder",
        icon: "linkedin"
      },
      {
        platform: "Twitter / X",
        url: "https://twitter.com/vedant_placeholder",
        username: "@vedant_dev",
        icon: "twitter"
      },
      {
        platform: "Direct Email",
        url: "mailto:vedant.developer@example.com",
        username: "vedant.developer@example.com",
        icon: "mail"
      }
    ]
  }
};

// Freeze object to protect configuration from accidental mutation during runtime
if (typeof Object.freeze === 'function') {
  Object.freeze(PORTFOLIO_DATA);
}
